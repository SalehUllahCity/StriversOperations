# StriversOperations
(Group 9) Team 26: StriversOperations

Team: Shakeel, Samir, Mai-linh, Hussein, Giacomo, Numair, Saleh | Coach: Dr Dhawal Beohar 
Team Leader (Marketing) - Filippo
Team Leader (Box Office) - Denis

Points of Contact:
[dhawal.beohar@city.ac.uk](mailto:dhawal.beohar@city.ac.uk)
[shakeel.aziz@city.ac.uk](mailto:shakeel.aziz@city.ac.uk)
[giacomo.dellacasa-saba@city.ac.uk](mailto:giacomo.dellacasa-saba@city.ac.uk)
[mai-linh.le@city.ac.uk](mailto:mai-linh.le@city.ac.uk)
[shakib.hossain@city.ac.uk](mailto:shakib.hossain@city.ac.uk) 
[muhammad.numair@city.ac.uk](mailto:muhammad.numair@city.ac.uk)
[saleh.ullah@city.ac.uk](mailto:saleh.ullah@city.ac.uk)

Operations deals with the Calendar of the venue, as well as the operations of day-to-day events and reviews.
